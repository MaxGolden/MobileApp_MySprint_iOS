//
//  MyCarrierAppSecurityStaticLib.h
//  MyCarrierAppSecurityStaticLib
//
//  Created by Tolulope Oridota on 7/16/19.
//  Copyright © 2019 Sprint. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyCarrierAppSecurityStaticLib : NSObject

@end
